package tests.generators.network;

import tests.generators.AbstractGenerator;
import vnreal.network.NetworkStack;

public abstract class AbstractNetworkStackGenerator extends AbstractGenerator<NetworkStack> {

}
