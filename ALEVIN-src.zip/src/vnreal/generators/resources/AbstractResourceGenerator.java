package vnreal.generators.resources;

import tests.generators.AbstractGenerator;

public abstract class AbstractResourceGenerator<T> extends AbstractGenerator<T> {

}
