package vnreal.algorithms.utils.tree;
/*
Copyright 2010 Vivin Suresh Paliath
Distributed under the BSD License
*/

public enum GenericTreeTraversalOrderEnum {
   PRE_ORDER,
   POST_ORDER
}