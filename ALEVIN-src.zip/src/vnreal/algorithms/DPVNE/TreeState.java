package vnreal.algorithms.DPVNE;

public enum TreeState {
	FULLY_LOCKED, PARTIALLY_LOCKED, UNLOCKED

}
