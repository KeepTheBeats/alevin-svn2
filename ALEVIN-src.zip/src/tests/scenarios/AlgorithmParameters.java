package tests.scenarios;


public abstract class AlgorithmParameters {
	
	public abstract String toString(String prefix);
	
}
