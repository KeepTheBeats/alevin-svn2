package vnreal.generators.demands;

import tests.generators.AbstractGenerator;

public abstract class AbstractDemandGenerator<T> extends AbstractGenerator<T> {

}
