package tests.generators.network;


public interface NetworkGeneratorParameter {

	public String getSuffix(String prefix);
	
	public String toString(String prefix);

}
