package tests.generators.network;

import java.util.ArrayList;

import vnreal.network.NetworkStack;

public class TestNetworkGenerator extends AbstractNetworkStackGenerator {

	@Override
	public NetworkStack generate(ArrayList<Object> parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void reset() {
		// TODO Auto-generated method stub

	}

}
