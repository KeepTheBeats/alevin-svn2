package vnreal.algorithms.distributedAlg.messages;

public enum MessageEnum {
	START,
	NOTIFY,
	NEXT,
	STOP,
	MSG,
	BELLMANFORD,
	IMPROVED_MSG
}